import java.io.Serializable;

public interface Response extends Serializable{
	
	public String toString();
	
}
